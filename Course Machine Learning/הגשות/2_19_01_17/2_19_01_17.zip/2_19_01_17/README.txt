Cant understand the pattern occuring in every run with a random bin-iter, where in the CM of each method
the detection of mail as not-spam is not good at all.

Also, looking at the plots of the data for that bin-iter, it looks very like the other iter-bins data which I find 
very strange!!

Neta,

Just as a reminder...you checked my program(acttually the data it works with) for different params...
distribution of various values, data look-alike etc...


It is not that it bothers me it is the fact that I cant depend on my code for learning and future use!!!!!


