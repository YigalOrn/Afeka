learn-prolog-now-exercises
======================

## What is this?
This repository contains my solutions to the exercises found in the
'Learn Prolog Now!' book by Patrick Blackburn, Johan Bos and Kristina
Striegnitz.

## General

- **Author:** Peter Urbak, peter@dragonwasrobot.com
- **Created:** 2012-07-01
- **Last Modified:** 2013-06-21
- **URL:** https://github.com/dragonwasrobot/learn-prolog-now-exercises
- **License:** Gnu General Public License

## TODO

- Finish any unsolved exercises/practical sessions.
- Proof read and check all the exercises + practical sessions.
- Add better documentation of the project.
