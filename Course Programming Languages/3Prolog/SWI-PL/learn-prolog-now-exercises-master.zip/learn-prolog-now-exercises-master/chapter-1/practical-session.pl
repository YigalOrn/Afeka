%% Chapter 1 - Practical Session

%% ?- listing. -> display content of current knowledge base.
%% ?- [kb2]. -> load kb2.pl (prepend path how?).
%% ?- listing(playsAirGuitar). -> outputs:
%% listing(playsAirGuitar).
%% playsAirGuitar(jody).
%% playsAirGuitar(mia) :-
%%  listensToMusic(mia).
%% ...
%% true