function [hmax,dmax]=trajectory(v0,theta)
% trajectory calculates the max height and distance of a projectile, and
% makes a plot of the trajectory.
% Input arguments are:
% v0: initioal velocity in [m/sec]
% theta: angel in degrees.
% Output arguments are:
% hmax: maximum height in [m]
% dmax: maimum distance in [m].
g=9.81;
v0x=v0*cosd(theta);
v0y=v0*sind(theta);
thmax=v0y/g;
hmax=v0x^2/(2*g);
ttot=2*thmax;
dmax=v0x*ttot;
% Create a trajectory plot
t=linspace(0,ttot,200);
x=v0x*t;
y=v0y*t-0.5*g*t.^2;
plot(x,y)
xlabel('Distance [m]'),ylabel('Height [m]')
title('Projectile''s Trajectory')
