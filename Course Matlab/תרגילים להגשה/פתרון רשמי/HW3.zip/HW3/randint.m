function n=randint(a,b)
% "randint" gives a random integer number within the range between two
%  integer numbers
n=round(a+rand*(b-a));
