function d=PtoLdist(x0,y0,A,B,C);
% "PtoLdist" determines the distance between a point and a straight line in
% the x-y plane
d=abs((A*x0+B*y0+C)/sqrt(A^2+B^2));
