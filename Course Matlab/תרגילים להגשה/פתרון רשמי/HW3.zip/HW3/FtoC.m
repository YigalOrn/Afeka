function C=FtoC(F)
% FtoC converts degrees F to degrees C
C=5*(F-32)./9;