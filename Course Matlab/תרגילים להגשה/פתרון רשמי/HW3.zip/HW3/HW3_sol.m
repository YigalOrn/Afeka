%% Solution for Homework assignment HW3:
clc,clear,format compact,format short


%% 1. 
clf, clear, clc
x=linspace(-300,300);
y=693.8-68.8.*cosh(x./99.7);
plot (x,y,'k--')

%% 2. 
clf, clear, clc
R=4; L=1.3; V=12;
t1=linspace(0,0.5);
t2=linspace(0.5,2);
i1=V/R.*(1-exp(-R.*t1./L));
i2=exp(-R.*t2./L).*V/R.*(exp(0.5*R./L)-1);
plot (t1,i1,'r--', t2,i2,'k:')
title('rectangular voltage sorce')
xlabel ('time [sec]'), ylabel ('current(i)')
legend ('charge', 'discharge')

%% 3. 
clf, clear, clc
a0=52.92e-11;
ra0=linspace(0,15);
P=1/8/a0*ra0.^2.*(2-ra0).*exp(-ra0);
plot(ra0,P)
title('radial probability density')
xlabel ('r/a0'), ylabel ('Pr')

%% 4. a. 
clf, clear, clc
x=linspace(-30,30);
f=7*x.^3+5*x.^2+7*x;
df=21*x.^2+10*x+7;
ddf=42*x+10;
subplot(1,3,1)
plot(x,f)
title('f(x)')
%
subplot(1,3,2)
plot(x,df,'r')
title('df/dx')
%
subplot(1,3,3)
plot(x,ddf,'g')
title('d^2f/dx^2')
%% 4. b. 
clc,clf,clear
t=linspace(0,7);
x=0.4*t.^3-2*t.^2-5*t+13;
v=0.4*3*t.^2-2*2*t-5;
a=0.4*3*2*t-2*2;
subplot(3,1,1)
plot(t,x),xlabel('t [sec]'), ylabel('x [m]'),title('Particle Position')
subplot(3,1,2)
plot(t,v),xlabel('t [sec]'), ylabel('v [m/sec]'),title('Particle Velocity')
subplot(3,1,3)
plot(t,a),xlabel('t [sec]'), ylabel('a [m/sec^2]'),title('Particle Acceleration')
%% 5. 
clc, clear,clf
c=0.05; b=3;
u=-36:0.2:36;
v1=sinexp1(b,c, u,u);
plot (u,v1), title('HW3. Ex.5')
%% 6. 
clc, clear
[x_a,y_a]=maxmin(3,-18,48);  % => x_a=3, y_a=21
[x_b,y_b]=maxmin(-5,10,-3);  % => x_b=1, y_b=2

%% 7. 

clc, clear
% a.
x0=2; y0=-4; A=-2; B=3.5; C=-6;
d_a=PtoLdist(x0,y0,A,B,C) % ==> d_a =    5.9537
% b.
x0=11; y0=2; A=-2; B=-1; C=6;
d_b=PtoLdist(x0,y0,A,B,C) % ==> d_b =    8.0498
%
%---------------------------------
%% 8.
clc,clf
help FtoC
%or:
doc FtoC
TFL=[49 48 51 54 63 67 70 72 69 59 54 47];
TFH=[65 66 69 72 77 83 86 86 89 83 76 66];
TCL=round(FtoC(TFL)');
TCH=round(FtoC(TFH)');
plot(TCL),hold on,grid on
plot(TCH,'r'),xlabel('Month'),ylabel('T[C]')
title('Tel-Aviv average temperatures')
legend('Low','High')

%% 9. 
clc, clear,clf
% a.
a=1; b=49;
n_a=randint(a,b) % for exaple ==> n_a = 32

% b.
a=-35; b=-2;
n_b=randint(a,b) % for exaple ==> n_b = -34
%
%---------------------------------

%% 10. 
clc,clear,clf
[h,d]=trajectory(230,39)

