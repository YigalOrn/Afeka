% This function is  a part of the solution for prob. 6-3
% It finds local max or min of f(x)=a*x^2+b*x+c
function [x,y]= minmax(a,b,c)

x = -b/(2*a);
y = a*x^2 + b*x + c;

%%determing if the coordinate is a min or max
tag = 2*a;

if tag > 0
    disp(['The coordinate of the min point are:  ', num2str([x,y])]);
else
     disp(['The coordinate of the max point are:  ', num2str([x,y])]);
end
