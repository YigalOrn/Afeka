% This function is  a part of the solution for HW4 Ex.4
function y=sinexp1 (b,c,x,y)
y=sin(c*x).*exp(-b.*y);
