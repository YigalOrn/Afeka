function y=downsort(x)
y1=x; % initial value

for t=2:length(x)
    for m=1:t-1
        if x(t)>=y1(t-m)
            y1(t-m+1)=y1(t-m);
            y1(t-m)=x(t);
        end
    end
end
y=y1;

