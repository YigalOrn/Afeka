%---------------------------------
%% Solution for Homework 4
%---------------------------------
%
%% General
clc, clear all; close all; format compact
%% 1. a)
clear all, clc
% the script file will contain:
xa=linspace(-6,6,101);
for t=1:length(xa) % a parameter (index in vector)
    if (xa(t)>=-6)&(xa(t)<=-2)
        f(t)=4*exp(xa(t)+2);
    elseif (xa(t)>=-2)&(xa(t)<=2)
        f(t)=xa(t)^2;
    else
        f(t)=(xa(t)+62)^(1/3);
    end
end
plot(xa,f), title('HW.4 Ex.1a')
%% 1. b)
clear all, clc
xb=linspace(-6,6,101);
fb=fx_Ex4_1(xb);
plot(xb,fb), title('HW.4 Ex.1b')

%% 2. 
% 
clc,clear
x=round(-30+60*rand(1,14))
% for example: 
% x = -23    -3    13    24   -14   -15    22   -16    18    25   -16   -16   -27   -25
y=downsort(x)
% y = 25    24    22    18    13    -3   -14   -15   -16   -16   -16   -23   -25   -27
% or:
y_2=downsort_2(x)
%% 3. a)
clc, clear
m=10;
% or you can use:   m=input(' the number of terms is ');
S1=0; % initialization
for n=0:m
    S1=S1+(-1)^n/(2*n+1);
end
S1
pi/4
m=500;
% or you can use:   m=input(' the number of terms is ');
S1=0; % initialization
for n=0:m
    S1=S1+(-1)^n/(2*n+1);
end
S1
pi/4
% runing with m=10 ==>
% the number of terms is 10
% S1 = 0.8081
% runing with m=500 ==>
 %the number of terms is 500
% S1 = 0.7859
% and the real limit:
% pi/4 
% ans = 0.7854


%% 3. b)
m=10;
% or you can use:   m=input(' the number of terms is ');
S1=0; % initialization
n=0; % initialization
while n<=m
    S1=S1+(-1)^n/(2*n+1);
    n=n+1;
end
S1
pi/4
m=500;
% or you can use:   m=input(' the number of terms is ');
S1=0; % initialization
n=0; % initialization
while n<=m
    S1=S1+(-1)^n/(2*n+1);
    n=n+1;
end
S1
pi/4
%% 4. 
clc ; clear all;
%n=input('Please choose a natural number  ');
n=7 % for example
A=binom(n)
%% 5. 
clf, clear, clc
% n=input('number of diamonds?  ');
n=10 % for example
IV=10; EV=12; SV=11;alpha=pi/50;
hold on
theta=0;
for i=1:n
        x(1)=IV*cos(theta);
        y(1)=IV*sin(theta);
        x(3)=EV*cos(theta);
        y(3)=EV*sin(theta);
        x(2)=SV*cos(theta+alpha);
        y(2)=SV*sin(theta+alpha);
        x(4)=SV*cos(theta-alpha);
        y(4)=SV*sin(theta-alpha);
        x(5)=x(1);        y(5)=y(1);
        plot(x,y)
        theta=theta+(2*pi/n);
end
hold off
%% 6. 
n=8;
for i=1:n
    stair(i-1,2*n-i,0,i); hold on
end
hold off
%% 7. 
% a.
p=[2 -3 4 1 0 0 1];
x=linspace(12,23);
y=polyval(p,x);
plot(x,y);

% b.
p = [1   -13  0   54   -72]
r = (roots(p))'
% c.
u=[2 3];v=[1 4];
w=conv(u,v);
error=w-[2 11 12]
% or
r1=[-4, -3/2]
r2=roots([2 11 12])'

%% 8.
[x,y,w]=maxormin(6,-18,6)
[x,y,w]=maxormin(-4,-20,5)
%% 9.
clc, clear
p1= [1    -1   -19   -11    30]
R1=roots(p1)
P1=root2poly(R1)
p2= [    1     6     3   -10     0     0]
R2=roots(p1)
P2=root2poly(R2)
%% 10.
% a.
u=[15 35 -37 -19  41 -15];
v=[5   0  -4   3];
[q,r]=deconv(u,v)
% b.
a = [3 6 9];
b = [1 2 0];
u=conv(a,b)
w1=polyder(u)
w2=polyder(a,b)





