function f=fx_Ex4_1(x)
% "fx_Ex7_7" solves Chapter 7. Ex. 7 b)
for t=1:length(x)
        if (x(t)>=-6)&(x(t)<=-2)
        f(t)=4*exp(x(t)+2);
    elseif (x(t)>=-2)&(x(t)<=2)
        f(t)=x(t)^2;
    else
        f(t)=(x(t)+62)^(1/3);
    end
end

