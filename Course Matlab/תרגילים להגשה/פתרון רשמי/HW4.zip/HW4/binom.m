function y=binom(x)
y=zeros(x);
y(1:x,1)=1;
for i=2:x
    for j=2:x
        y(i,j)=y(i-1,j-1)+y(i-1,j);
    end
end
