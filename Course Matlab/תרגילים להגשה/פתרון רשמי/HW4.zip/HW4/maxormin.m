function [x,y,w]=maxormin(a,b,c)
% for y=a*x^2+b*x+c
% x is the coordinate of the max/min
% y is the value of the function at that point
% w=1 if y is a maximum, w=2 if y is a minimum
p=[a,b,c];
k=polyder(p); % k=dp/dx
x=roots (k);   % dp/dx=0 =>x
y=polyval (p,x);
m=polyder(k); %  
if m<0
    w=1;
elseif m>0
    w=2;
else
    disp(' saddle point ');
end
