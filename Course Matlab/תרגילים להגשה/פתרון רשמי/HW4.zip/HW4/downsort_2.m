function y =downsort_2(x)

for i=1:1:length(x)

    y(i)=max(x);
  A= find(x==max(x));
  x(A(1))=[];
end