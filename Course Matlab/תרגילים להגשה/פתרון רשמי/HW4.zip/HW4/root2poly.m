function [p]=root2poly(R)
p=[1];
for i=R'
    p=conv(p,[1,-i]);
end