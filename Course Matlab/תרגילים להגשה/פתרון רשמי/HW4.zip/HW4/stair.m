function stair(xo,xf,zo,zf)
plot([xo xf xf xo xo],[zo zo zf zf zo])
