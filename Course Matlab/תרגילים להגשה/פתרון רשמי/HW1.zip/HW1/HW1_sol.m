%--------------------------------------------------------------------------
%% Solution for Homework assignment HW1:
clc,clear,format compact
%--------------------------------------------------------------------------
%% 1. 
x=9.6;z=8.1;
Ex1a=x*z^2-(2*z/(3*x))^(3/5) % Ex1a =  629.1479
Ex1b=443*z/(2*x^3)+exp(-x*z)/(x+z)% Ex1b = 2.0279
%% 2. 
x=5*pi/24;
Ex2a_left=sin(2*x) % Ex2a_left= 0.9659
Ex2a_right=2*sin(x)*cos(x) % Ex2a_right= 0.9659
Ex2b_left=cos(x/2) % Ex2b_left= 0.9469
Ex2c_right=sqrt((1+cos(x))/2) % Ex2c_right= 0.9469
%% 3. 
x=3*pi/17;
a1=tan(2*x), a2=2*tan(x)/(1-tan(x)^2) % a1=a2=2.0083
b1=tan(x/2), b2=sqrt((1-cos(x))/(1+cos(x))) %b1=b2=0.2845
%% 4. 
alpha=5*pi/9;beta=pi/7;
Ex4_left=cos(alpha)-cos(beta) % Ex4_left= -1.0746
Ex4_right=2*sin(0.5*(alpha+beta))*sin(0.5*(beta-alpha)) % Ex4_right= -1.0746
%% 5. 
a=11;c=21;
b=sqrt(c^2-a^2) % b =   17.8885
alpha=acosd(b/c) % alpha =  31.5881
%% 6. 
a=18; b=35; c=50;
Gamma=acosd((a^2+b^2-c^2)/(2*a*b)) %139.0046
%% 7. 
x0=2; y0=-3; A=3; B=5; C=-6;
d=abs(A*x0+B*y0+C)/sqrt(A^2+B^2) % d=2.5725
%% 8. 
m=12;flowers=751;
packs=ceil(flowers/m) % packs = 63
%% 9. 
table_price=256.95;
chair_price=89.99;
format bank
total_cost=2*table_price+8*chair_price % (a) total_cost =1233.82
after_tax=total_cost*(105.5/100) % (b) after_tax = 1301.68
round_cost=round(after_tax) % (c) round_cost = 1302.00
%% 10. 
% Search the "?" help for "least common multiple"
Ex10a=lcm(4,10) %(a) Ex10a = 20.00
Ex10b=lcm(6,38) % (b)Ex10b = 114.00