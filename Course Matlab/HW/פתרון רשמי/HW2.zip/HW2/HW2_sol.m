%% Solution for Homework assignment HW2:
clc,clear,format compact

%% 1.
% 1a
clc;clear all;
v=linspace(7,40,14)
% 1.b.
b=[v(1) v(5) v(6)]
% 1.c.
c=[v(8:14) v(1:7)]
% 1.d.
d=v(2:end-1)
% 1.h.
h=v(end:-1:1)
%% 2. 
clc;clear all
x=[-2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3];
y=(x.^2+1).^3.*x.^3
%% 3.
clc;clear all
t=1:10;
g=9.81;
d=0.5*g*t.^2;
%% 4.
clc;clear all
a=50;
na=0:a;
xa=1./((2*na+1).*(2*na+2));
ya=sum(xa)
b=500;
nb=0:b;
xb=1./((2*nb+1).*(2*nb+2));
yb=sum(xb)
c=5000;
nc=0:c;
xc=1./((2*nc+1).*(2*nc+2));
yc=sum(xc)
y=log(2)
%% 5.
clc;clear all
MULT=[1:10]'*[1:10]
%% 6.
clc;clear all;
A = [2,-3,4; 1,1,4; 3,4,-2];
b = [5; 10; 0];
x=A\b;
%% 7.
clc;clear all
x=[-2; -0.5; 1; 2.5];
y=[-3.4; 5.525; 16.7; 70.625];
A=[x.^3, x.^2, x, ones(4,1)]; % y=A*v
v=A\y
%% 8.
clc;clear all
v=2:2:70
A=reshape(v,7,5)'
B=[A(3:5,4:7)]
%% 9.
clc;clear all
a=10;b=60;
A=rand(1000,1000)*(b-a)+a;
A_average=mean(A(:))
%% 10.
clc;clear all
% 10a
a=3;b=10;
n=rand*(b-a)+a;
% 10b
x=linspace(3,2*n,n)
% 10c
x_sort=sort(x,'descend')
% 10d
x_sum=sum(x)











