function [ n ] = randint(a,b)

%..........................

n = round(   rand(1,1)*(b-a)+a   ) ;

end

