#include <iostream>
using namespace std;

#include "Attendant.h"

const int Attendant::MAX_NUMBER_OF_LANGUAGES = 10;

